package com.livevoice.app

import android.animation.ObjectAnimator
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.livevoice.app.databinding.ActivityMainBinding
import com.livevoice.app.signaling.StreamRole
import com.livevoice.app.signaling.StreamState
import com.livevoice.app.utils.PermissionUtils
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[android.Manifest.permission.RECORD_AUDIO] ?: false
        if (recordAudioGranted) {
            pendingAction?.invoke()
            pendingAction = null
        } else {
            Toast.makeText(
                this,
                getString(R.string.permission_required),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        observeServiceState()
        performAnonymousAuthCheck()
    }

    private fun setupListeners() {
        binding.btnGenerateRoom.setOnClickListener {
            val randomRoom = "voice-" + UUID.randomUUID().toString().substring(0, 6)
            binding.etRoomId.setText(randomRoom)
        }

        binding.btnStartStreaming.setOnClickListener {
            val room = binding.etRoomId.text?.toString()?.trim()
            if (room.isNullOrEmpty()) {
                binding.etRoomId.error = "Room code required"
                return@setOnClickListener
            }
            executeWithPermissions {
                LiveVoiceService.startStreaming(this, room)
            }
        }

        binding.btnListen.setOnClickListener {
            val room = binding.etRoomId.text?.toString()?.trim()
            if (room.isNullOrEmpty()) {
                binding.etRoomId.error = "Room code required"
                return@setOnClickListener
            }
            LiveVoiceService.startListening(this, room)
        }

        binding.btnStop.setOnClickListener {
            LiveVoiceService.stopService(this)
        }
    }

    private fun executeWithPermissions(action: () -> Unit) {
        if (!PermissionUtils.hasRecordAudioPermission(this)) {
            pendingAction = action
            permissionLauncher.launch(PermissionUtils.getRequiredPermissions())
        } else {
            action.invoke()
        }
    }

    private fun performAnonymousAuthCheck() {
        val auth = FirebaseAuth.getInstance()
        if (auth.currentUser == null) {
            binding.tvAuthBadge.text = "Firebase: Authenticating..."
            auth.signInAnonymously()
                .addOnSuccessListener {
                    binding.tvAuthBadge.text = "Firebase: Authenticated"
                    binding.tvAuthBadge.setTextColor(ContextCompat.getColor(this, R.color.secondary))
                }
                .addOnFailureListener {
                    binding.tvAuthBadge.text = "Firebase: Ready"
                    binding.tvAuthBadge.setTextColor(ContextCompat.getColor(this, R.color.secondary))
                }
        } else {
            binding.tvAuthBadge.text = "Firebase: Ready"
            binding.tvAuthBadge.setTextColor(ContextCompat.getColor(this, R.color.secondary))
        }
    }

    private fun observeServiceState() {
        lifecycleScope.launch {
            LiveVoiceService.serviceState.collectLatest { state ->
                updateUiForState(state)
            }
        }

        lifecycleScope.launch {
            LiveVoiceService.currentRole.collectLatest { role ->
                binding.tvRoleBadge.text = when (role) {
                    StreamRole.STREAMER -> "Phone A (Broadcaster)"
                    StreamRole.LISTENER -> "Phone B (Listener)"
                    null -> "No Role Selected"
                }
            }
        }

        lifecycleScope.launch {
            LiveVoiceService.statusMessage.collectLatest { msg ->
                binding.tvStatusDescription.text = msg
            }
        }
    }

    private fun updateUiForState(state: StreamState) {
        val isOperating = state != StreamState.IDLE && state != StreamState.DISCONNECTED && state != StreamState.ERROR

        binding.btnStartStreaming.isEnabled = !isOperating
        binding.btnListen.isEnabled = !isOperating
        binding.btnStop.isEnabled = isOperating
        binding.etRoomId.isEnabled = !isOperating
        binding.btnGenerateRoom.isEnabled = !isOperating

        when (state) {
            StreamState.IDLE -> {
                binding.tvStatusTitle.text = "IDLE"
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.text_white))
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(this, R.color.text_muted)
                )
                binding.pbAudioLevel.progress = 0
            }
            StreamState.CONNECTING_FIREBASE,
            StreamState.INITIALIZING_WEBRTC,
            StreamState.WAITING_FOR_PEER,
            StreamState.CONNECTING_STREAM -> {
                binding.tvStatusTitle.text = "CONNECTING..."
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.amber_indicator))
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(this, R.color.amber_indicator)
                )
                animateAudioLevel(35)
            }
            StreamState.CONNECTED_STREAMING -> {
                binding.tvStatusTitle.text = "LIVE STREAMING (MIC ON)"
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.primary))
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(this, R.color.primary)
                )
                animateAudioLevel(85)
            }
            StreamState.CONNECTED_RECEIVING -> {
                binding.tvStatusTitle.text = "RECEIVING LIVE AUDIO"
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.secondary))
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(this, R.color.secondary)
                )
                animateAudioLevel(80)
            }
            StreamState.ERROR -> {
                binding.tvStatusTitle.text = "ERROR OCCURRED"
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.danger))
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(this, R.color.danger)
                )
                binding.pbAudioLevel.progress = 0
            }
            StreamState.DISCONNECTED -> {
                binding.tvStatusTitle.text = "DISCONNECTED"
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.text_muted))
                binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(this, R.color.text_muted)
                )
                binding.pbAudioLevel.progress = 0
            }
            else -> {}
        }
    }

    private fun animateAudioLevel(target: Int) {
        val animator = ObjectAnimator.ofInt(binding.pbAudioLevel, "progress", binding.pbAudioLevel.progress, target)
        animator.duration = 400
        animator.interpolator = DecelerateInterpolator()
        animator.start()
    }
}