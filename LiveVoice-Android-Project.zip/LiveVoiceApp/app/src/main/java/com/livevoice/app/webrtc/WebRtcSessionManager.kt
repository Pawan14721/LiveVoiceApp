package com.livevoice.app.webrtc

import android.content.Context
import android.util.Log
import com.livevoice.app.signaling.StreamRole
import org.webrtc.*

class WebRtcSessionManager(
    private val context: Context,
    private val role: StreamRole
) {
    companion object {
        private const val TAG = "WebRtcSessionManager"
        private const val AUDIO_TRACK_ID = "live_voice_audio_track"
    }

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var localAudioTrack: AudioTrack? = null

    interface WebRtcEvents {
        fun onIceCandidateGathered(candidate: IceCandidate)
        fun onOfferCreated(sdp: SessionDescription)
        fun onAnswerCreated(sdp: SessionDescription)
        fun onConnectionStateChange(state: PeerConnection.IceConnectionState)
        fun onRemoteAudioTrackReceived(track: AudioTrack)
        fun onError(error: String)
    }

    private var eventListener: WebRtcEvents? = null

    fun setEventListener(listener: WebRtcEvents) {
        this.eventListener = listener
    }

    fun init() {
        val initOptions = PeerConnectionFactory.InitializationOptions.builder(context)
            .setEnableInternalTracer(false)
            .createInitializationOptions()
        PeerConnectionFactory.initialize(initOptions)

        val factoryOptions = PeerConnectionFactory.Options()
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setOptions(factoryOptions)
            .createPeerConnectionFactory()

        createPeerConnection()

        if (role == StreamRole.STREAMER) {
            setupLocalAudioCapture()
        }
    }

    private fun createPeerConnection() {
        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer()
        )

        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            keyType = PeerConnection.KeyType.ECDSA
            enableDtlsSrtp = true
        }

        peerConnection = peerConnectionFactory?.createPeerConnection(
            rtcConfig,
            object : SimplePeerConnectionObserver(TAG) {
                override fun onIceCandidate(candidate: IceCandidate?) {
                    super.onIceCandidate(candidate)
                    candidate?.let { eventListener?.onIceCandidateGathered(it) }
                }

                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    super.onIceConnectionChange(state)
                    state?.let { eventListener?.onConnectionStateChange(it) }
                }

                override fun onAddTrack(receiver: RtpReceiver?, mediaStreams: Array<out MediaStream>?) {
                    super.onAddTrack(receiver, mediaStreams)
                    val track = receiver?.track()
                    if (track is AudioTrack) {
                        track.setEnabled(true)
                        eventListener?.onRemoteAudioTrackReceived(track)
                    }
                }
            }
        )
    }

    private fun setupLocalAudioCapture() {
        val factory = peerConnectionFactory ?: return
        val audioConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
        }

        audioSource = factory.createAudioSource(audioConstraints)
        localAudioTrack = factory.createAudioTrack(AUDIO_TRACK_ID, audioSource).apply {
            setEnabled(true)
        }

        peerConnection?.addTrack(localAudioTrack, listOf("live_voice_stream"))
    }

    fun startStreamingOffer() {
        val sdpConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        }

        peerConnection?.createOffer(object : SimpleSdpObserver(TAG) {
            override fun onCreateSuccess(desc: SessionDescription?) {
                super.onCreateSuccess(desc)
                desc?.let { offer ->
                    peerConnection?.setLocalDescription(object : SimpleSdpObserver(TAG) {
                        override fun onSetSuccess() {
                            super.onSetSuccess()
                            eventListener?.onOfferCreated(offer)
                        }
                    }, offer)
                }
            }

            override fun onCreateFailure(error: String?) {
                super.onCreateFailure(error)
                eventListener?.onError("Failed to create WebRTC offer: $error")
            }
        }, sdpConstraints)
    }

    fun onRemoteOfferReceived(remoteOffer: SessionDescription) {
        peerConnection?.setRemoteDescription(object : SimpleSdpObserver(TAG) {
            override fun onSetSuccess() {
                super.onSetSuccess()
                createAnswer()
            }

            override fun onSetFailure(error: String?) {
                super.onSetFailure(error)
                eventListener?.onError("Failed to set remote offer: $error")
            }
        }, remoteOffer)
    }

    private fun createAnswer() {
        val sdpConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        }

        peerConnection?.createAnswer(object : SimpleSdpObserver(TAG) {
            override fun onCreateSuccess(desc: SessionDescription?) {
                super.onCreateSuccess(desc)
                desc?.let { answer ->
                    peerConnection?.setLocalDescription(object : SimpleSdpObserver(TAG) {
                        override fun onSetSuccess() {
                            super.onSetSuccess()
                            eventListener?.onAnswerCreated(answer)
                        }
                    }, answer)
                }
            }

            override fun onCreateFailure(error: String?) {
                super.onCreateFailure(error)
                eventListener?.onError("Failed to create answer: $error")
            }
        }, sdpConstraints)
    }

    fun onRemoteAnswerReceived(remoteAnswer: SessionDescription) {
        peerConnection?.setRemoteDescription(object : SimpleSdpObserver(TAG) {
            override fun onSetSuccess() {
                super.onSetSuccess()
            }

            override fun onSetFailure(error: String?) {
                super.onSetFailure(error)
                eventListener?.onError("Failed to set remote answer: $error")
            }
        }, remoteAnswer)
    }

    fun addRemoteIceCandidate(candidate: IceCandidate) {
        peerConnection?.addIceCandidate(candidate)
    }

    fun dispose() {
        try {
            localAudioTrack?.setEnabled(false)
            localAudioTrack?.dispose()
            localAudioTrack = null

            audioSource?.dispose()
            audioSource = null

            peerConnection?.close()
            peerConnection?.dispose()
            peerConnection = null

            peerConnectionFactory?.dispose()
            peerConnectionFactory = null
        } catch (e: Exception) {
            Log.e(TAG, "Error disposing WebRTC: ${e.message}")
        }
    }
}