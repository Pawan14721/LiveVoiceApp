package com.livevoice.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.livevoice.app.signaling.FirebaseSignalingClient
import com.livevoice.app.signaling.StreamRole
import com.livevoice.app.signaling.StreamState
import com.livevoice.app.webrtc.WebRtcSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.webrtc.AudioTrack
import org.webrtc.IceCandidate
import org.webrtc.PeerConnection
import org.webrtc.SessionDescription

class LiveVoiceService : Service() {

    companion object {
        private const val TAG = "LiveVoiceService"
        private const val NOTIFICATION_ID = 9021
        private const val CHANNEL_ID = "live_voice_audio_channel"

        const val ACTION_START_STREAM = "com.livevoice.app.ACTION_START_STREAM"
        const val ACTION_START_LISTEN = "com.livevoice.app.ACTION_START_LISTEN"
        const val ACTION_STOP = "com.livevoice.app.ACTION_STOP"
        const val EXTRA_ROOM_ID = "extra_room_id"

        private val _serviceState = MutableStateFlow(StreamState.IDLE)
        val serviceState: StateFlow<StreamState> = _serviceState

        private val _currentRole = MutableStateFlow<StreamRole?>(null)
        val currentRole: StateFlow<StreamRole?> = _currentRole

        private val _currentRoomId = MutableStateFlow("")
        val currentRoomId: StateFlow<String> = _currentRoomId

        private val _statusMessage = MutableStateFlow("Idle")
        val statusMessage: StateFlow<String> = _statusMessage

        fun startStreaming(context: Context, roomId: String) {
            val intent = Intent(context, LiveVoiceService::class.java).apply {
                action = ACTION_START_STREAM
                putExtra(EXTRA_ROOM_ID, roomId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun startListening(context: Context, roomId: String) {
            val intent = Intent(context, LiveVoiceService::class.java).apply {
                action = ACTION_START_LISTEN
                putExtra(EXTRA_ROOM_ID, roomId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, LiveVoiceService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null

    private var signalingClient: FirebaseSignalingClient? = null
    private var webrtcManager: WebRtcSessionManager? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val roomId = intent?.getStringExtra(EXTRA_ROOM_ID) ?: "default-room"

        when (action) {
            ACTION_START_STREAM -> {
                startForegroundWithNotification(StreamRole.STREAMER, roomId)
                initSession(StreamRole.STREAMER, roomId)
            }
            ACTION_START_LISTEN -> {
                startForegroundWithNotification(StreamRole.LISTENER, roomId)
                initSession(StreamRole.LISTENER, roomId)
            }
            ACTION_STOP -> {
                terminateSession()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "LiveVoice::StreamingWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(24 * 60 * 60 * 1000L)
            }
            Log.d(TAG, "WakeLock acquired: screen off audio supported")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to acquire WakeLock: ${e.message}")
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing WakeLock: ${e.message}")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_desc)
                setShowBadge(false)
                setSound(null, null)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundWithNotification(role: StreamRole, roomId: String) {
        val title = if (role == StreamRole.STREAMER) {
            "LiveVoice: Streaming Live Audio"
        } else {
            "LiveVoice: Receiving Live Audio"
        }
        val text = "Room: $roomId • Screen off streaming active"

        val openActivityIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, LiveVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(if (role == StreamRole.STREAMER) R.drawable.ic_mic else R.drawable.ic_headphones)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_stop, "Stop", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val type = if (role == StreamRole.STREAMER) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (role == StreamRole.STREAMER) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                0
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initSession(role: StreamRole, roomId: String) {
        _currentRole.value = role
        _currentRoomId.value = roomId
        _serviceState.value = StreamState.CONNECTING_FIREBASE
        _statusMessage.value = "Authenticating with Firebase..."

        serviceScope.launch {
            try {
                signalingClient = FirebaseSignalingClient(roomId, role)
                val uid = signalingClient!!.authenticateAnonymously()
                Log.d(TAG, "Authenticated anonymously UID: $uid")

                _serviceState.value = StreamState.INITIALIZING_WEBRTC
                _statusMessage.value = "Initializing WebRTC engine..."

                webrtcManager = WebRtcSessionManager(applicationContext, role)

                webrtcManager!!.setEventListener(object : WebRtcSessionManager.WebRtcEvents {
                    override fun onIceCandidateGathered(candidate: IceCandidate) {
                        signalingClient?.sendIceCandidate(candidate)
                    }

                    override fun onOfferCreated(sdp: SessionDescription) {
                        _statusMessage.value = "Offer published. Waiting for listener..."
                        signalingClient?.sendOffer(sdp)
                    }

                    override fun onAnswerCreated(sdp: SessionDescription) {
                        _statusMessage.value = "Answer published. Connecting WebRTC..."
                        signalingClient?.sendAnswer(sdp)
                    }

                    override fun onConnectionStateChange(state: PeerConnection.IceConnectionState) {
                        when (state) {
                            PeerConnection.IceConnectionState.CONNECTED,
                            PeerConnection.IceConnectionState.COMPLETED -> {
                                _serviceState.value = if (role == StreamRole.STREAMER) {
                                    StreamState.CONNECTED_STREAMING
                                } else {
                                    StreamState.CONNECTED_RECEIVING
                                }
                                _statusMessage.value = "Connected! Real-time voice active."
                            }
                            PeerConnection.IceConnectionState.DISCONNECTED -> {
                                _statusMessage.value = "Peer disconnected."
                            }
                            PeerConnection.IceConnectionState.FAILED -> {
                                _serviceState.value = StreamState.ERROR
                                _statusMessage.value = "Connection failed. Check network."
                            }
                            else -> {}
                        }
                    }

                    override fun onRemoteAudioTrackReceived(track: AudioTrack) {
                        Log.d(TAG, "Playing incoming audio track in real time.")
                    }

                    override fun onError(error: String) {
                        _serviceState.value = StreamState.ERROR
                        _statusMessage.value = error
                    }
                })

                signalingClient!!.setCallback(object : FirebaseSignalingClient.SignalingCallback {
                    override fun onOfferReceived(description: SessionDescription) {
                        webrtcManager?.onRemoteOfferReceived(description)
                    }

                    override fun onAnswerReceived(description: SessionDescription) {
                        webrtcManager?.onRemoteAnswerReceived(description)
                    }

                    override fun onIceCandidateReceived(candidate: IceCandidate) {
                        webrtcManager?.addRemoteIceCandidate(candidate)
                    }

                    override fun onError(message: String) {
                        _statusMessage.value = message
                    }
                })

                webrtcManager!!.init()
                signalingClient!!.startListeningForSignaling()

                if (role == StreamRole.STREAMER) {
                    _statusMessage.value = "Creating WebRTC Offer..."
                    webrtcManager!!.startStreamingOffer()
                } else {
                    _statusMessage.value = "Waiting for live broadcast in room $roomId..."
                }

            } catch (e: Exception) {
                Log.e(TAG, "Session init failed: ${e.message}", e)
                _serviceState.value = StreamState.ERROR
                _statusMessage.value = "Error: ${e.message}"
            }
        }
    }

    private fun terminateSession() {
        try {
            signalingClient?.cleanup()
            signalingClient = null

            webrtcManager?.dispose()
            webrtcManager = null

            _serviceState.value = StreamState.IDLE
            _currentRole.value = null
            _statusMessage.value = "Audio session stopped."
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping session: ${e.message}")
        }
    }

    override fun onDestroy() {
        terminateSession()
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}