package com.livevoice.app.signaling

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.tasks.await
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription

class FirebaseSignalingClient(
    private val roomId: String,
    private val role: StreamRole
) {
    companion object {
        private const val TAG = "LiveVoiceSignaling"
        private const val FIREBASE_DATABASE_URL = "https://voice-286b7-default-rtdb.firebaseio.com"
    }

    private val auth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance(FIREBASE_DATABASE_URL)
    private val roomRef: DatabaseReference = database.reference.child("rooms").child(roomId)

    private var answerListener: ValueEventListener? = null
    private var offerListener: ValueEventListener? = null
    private var candidateListener: ChildEventListener? = null

    interface SignalingCallback {
        fun onOfferReceived(description: SessionDescription)
        fun onAnswerReceived(description: SessionDescription)
        fun onIceCandidateReceived(candidate: IceCandidate)
        fun onError(message: String)
    }

    private var callback: SignalingCallback? = null

    fun setCallback(callback: SignalingCallback) {
        this.callback = callback
    }

    suspend fun authenticateAnonymously(): String {
        return try {
            val user = auth.currentUser
            if (user != null) {
                user.uid
            } else {
                val result = auth.signInAnonymously().await()
                result.user?.uid ?: "anonymous"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Firebase auth error: ${e.message}", e)
            "anonymous-fallback"
        }
    }

    fun sendOffer(sdp: SessionDescription) {
        val model = SessionDescriptionModel(type = sdp.type.canonicalForm(), sdp = sdp.description)
        roomRef.child("offer").setValue(model)
            .addOnSuccessListener {
                roomRef.child("status").setValue("offer_published")
            }
            .addOnFailureListener { e ->
                callback?.onError("Failed to publish offer: ${e.message}")
            }
    }

    fun sendAnswer(sdp: SessionDescription) {
        val model = SessionDescriptionModel(type = sdp.type.canonicalForm(), sdp = sdp.description)
        roomRef.child("answer").setValue(model)
            .addOnSuccessListener {
                roomRef.child("status").setValue("answer_published")
            }
            .addOnFailureListener { e ->
                callback?.onError("Failed to publish answer: ${e.message}")
            }
    }

    fun sendIceCandidate(candidate: IceCandidate) {
        val candidateModel = IceCandidateModel(
            sdpMid = candidate.sdpMid,
            sdpMLineIndex = candidate.sdpMLineIndex,
            sdp = candidate.sdp
        )
        val targetNode = if (role == StreamRole.STREAMER) "offerCandidates" else "answerCandidates"
        roomRef.child("candidates").child(targetNode).push().setValue(candidateModel)
    }

    fun startListeningForSignaling() {
        if (role == StreamRole.STREAMER) {
            answerListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val answer = snapshot.getValue(SessionDescriptionModel::class.java)
                    if (answer != null && !answer.sdp.isNullOrEmpty()) {
                        val sdp = SessionDescription(SessionDescription.Type.ANSWER, answer.sdp)
                        callback?.onAnswerReceived(sdp)
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            roomRef.child("answer").addValueEventListener(answerListener!!)

            candidateListener = object : ChildEventListener {
                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                    val candidate = snapshot.getValue(IceCandidateModel::class.java)
                    if (candidate != null && !candidate.sdp.isNullOrEmpty()) {
                        callback?.onIceCandidateReceived(
                            IceCandidate(candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdp)
                        )
                    }
                }
                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
                override fun onChildRemoved(snapshot: DataSnapshot) {}
                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
                override fun onCancelled(error: DatabaseError) {}
            }
            roomRef.child("candidates").child("answerCandidates").addChildEventListener(candidateListener!!)

        } else {
            offerListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val offer = snapshot.getValue(SessionDescriptionModel::class.java)
                    if (offer != null && !offer.sdp.isNullOrEmpty()) {
                        val sdp = SessionDescription(SessionDescription.Type.OFFER, offer.sdp)
                        callback?.onOfferReceived(sdp)
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            roomRef.child("offer").addValueEventListener(offerListener!!)

            candidateListener = object : ChildEventListener {
                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                    val candidate = snapshot.getValue(IceCandidateModel::class.java)
                    if (candidate != null && !candidate.sdp.isNullOrEmpty()) {
                        callback?.onIceCandidateReceived(
                            IceCandidate(candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdp)
                        )
                    }
                }
                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
                override fun onChildRemoved(snapshot: DataSnapshot) {}
                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
                override fun onCancelled(error: DatabaseError) {}
            }
            roomRef.child("candidates").child("offerCandidates").addChildEventListener(candidateListener!!)
        }
    }

    fun cleanup() {
        try {
            answerListener?.let { roomRef.child("answer").removeEventListener(it) }
            offerListener?.let { roomRef.child("offer").removeEventListener(it) }
            candidateListener?.let {
                val targetNode = if (role == StreamRole.STREAMER) "answerCandidates" else "offerCandidates"
                roomRef.child("candidates").child(targetNode).removeEventListener(it)
            }
            if (role == StreamRole.STREAMER) {
                roomRef.removeValue()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up signaling: ${e.message}")
        }
    }
}